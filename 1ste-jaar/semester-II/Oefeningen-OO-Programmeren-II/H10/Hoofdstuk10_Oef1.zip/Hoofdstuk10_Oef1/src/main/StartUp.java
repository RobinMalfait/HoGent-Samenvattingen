package main;

import ui.Hoofdstuk10_Oef1;

/**
 *
 * @author robin
 */
public class StartUp 
{
    public static void main(String[] args)
    {
        (new Hoofdstuk10_Oef1()).start();
    }
}
