package domein;

/**
 *
 * @author robin
 */
public class Wapen extends Voorwerp
{

    private int kracht;
    private boolean gebruikt;

    public Wapen(String naam, double gewicht, int niveau, int kracht, boolean gebruikt)
    {
        super(naam, gewicht, niveau);

        this.stelKrachtIn(kracht);
        this.stelGebruiktIn(gebruikt);
    }

    public int getKracht()
    {
        return kracht;
    }

    public void setKracht(int kracht)
    {
        this.stelKrachtIn(kracht);
    }

    private void stelKrachtIn(int kracht)
    {
        if (kracht < 0)
        {
            throw new IllegalArgumentException("De kracht moet positief zijn.");
        }

        this.kracht = kracht;
    }

    public boolean isGebruikt()
    {
        return gebruikt;
    }

    public void setGebruikt(boolean gebruikt)
    {
        this.stelGebruiktIn(gebruikt);
    }

    private void stelGebruiktIn(boolean gebruikt)
    {
        this.gebruikt = gebruikt;
    }

    @Override
    public void setNiveau(int niveau)
    {
        if (niveau < 1 || niveau > 5)
        {
            throw new IllegalArgumentException("Het niveau moet in het interval [1, 10] liggen.");
        }

        super.setNiveau(niveau);
    }
   
    @Override
    public boolean isDraagbaar()
    {
        return true;
    }

    @Override
    public String toString()
    {
        return String.format("%s en met kracht %d %s gebruikt.", super.toString(), this.kracht, this.gebruikt ? "al" : "nog niet");
    }

}
