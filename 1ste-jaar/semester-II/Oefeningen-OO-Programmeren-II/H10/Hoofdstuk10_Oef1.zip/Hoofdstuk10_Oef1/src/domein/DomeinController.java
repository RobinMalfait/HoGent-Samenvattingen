package domein;

/**
 *
 * @author robin
 */
public class DomeinController 
{
    
    private final VoorwerpRepository voorwerpRepo;
    
    public DomeinController()
    {
        this.voorwerpRepo = new VoorwerpRepository();
    }
    
    public void voegWapenToe(String naam, double gewicht, int niveau, int kracht, boolean gebruikt)
    {
        this.voorwerpRepo.voegVoorwerpToe(new Wapen(naam, gewicht, niveau, kracht, gebruikt));
    }
    
    public void voegSleutelToe(String naam, double gewicht, int niveau, int deur)
    {
        this.voorwerpRepo.voegVoorwerpToe(new Sleutel(naam, gewicht, niveau, deur));
    }
    
    public String toonOverzicht()
    {
        return this.voorwerpRepo.toonOverzicht();
    }
}
