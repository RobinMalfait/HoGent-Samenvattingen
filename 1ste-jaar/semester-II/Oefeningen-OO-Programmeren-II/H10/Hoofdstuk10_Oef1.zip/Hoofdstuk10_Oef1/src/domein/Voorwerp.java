package domein;

/**
 *
 * @author robin
 */
abstract public class Voorwerp
{

    private final String naam;
    private double gewicht;
    private int niveau;

    public Voorwerp(String naam, double gewicht, int niveau)
    {
        this.naam = naam;

        this.stelGewichtIn(gewicht);
        this.stelNiveauIn(niveau);
    }

    public String getNaam()
    {
        return naam;
    }

    public double getGewicht()
    {
        return gewicht;
    }

    public int getNiveau()
    {
        return niveau;
    }

    public void setGewicht(double gewicht)
    {
        this.stelGewichtIn(gewicht);
    }

    public void setNiveau(int niveau)
    {
        this.stelNiveauIn(niveau);
    }

    private void stelGewichtIn(double gewicht)
    {
        if (gewicht < 0 || gewicht > 1000)
        {
            throw new IllegalArgumentException("Het gewicht moet positief zijn, en kleiner dan 1000kg.");
        }

        this.gewicht = gewicht;
    }

    private void stelNiveauIn(int niveau)
    {
        if (niveau < 1 || niveau > 10)
        {
            throw new IllegalArgumentException("Het niveau moet in het interval [1, 10] liggen.");
        }

        this.niveau = niveau;
    }
    
    abstract public boolean isDraagbaar();

    @Override
    public String toString()
    {
        return String.format("%s %s met gewicht %.3f kg uit niveau %d",
                this.getClass().getSimpleName(),
                this.naam,
                this.gewicht,
                this.niveau
        );
    }

}
