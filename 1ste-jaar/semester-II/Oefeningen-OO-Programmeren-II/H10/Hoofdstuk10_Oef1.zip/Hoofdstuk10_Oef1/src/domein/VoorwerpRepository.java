package domein;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author robin
 */
public class VoorwerpRepository 
{
    
    private final List<Voorwerp> collectie;

    public VoorwerpRepository()
    {
        this.collectie = new ArrayList<>();
    }
    
    public void voegVoorwerpToe(Voorwerp voorwerp)
    {
        this.collectie.add(voorwerp);
    }
    
    public String toonOverzicht()
    {
        if (this.collectie.isEmpty()) {
            return "collectie is leeg\n";
        }

        String output = "";

        for (Voorwerp voorwerp : this.collectie)
        {
            output += String.format("%s%n%n", voorwerp);
        }

        return output;
    }
}
