package domein;

/**
 *
 * @author robin
 */
public class Gebouw implements Draagbaar
{
    private String naam;
    
    private double hoogte;
    
    public Gebouw(String naam, double hoogte)
    {
        this.naam = naam;
        this.stelHoogteIn(hoogte);
    }

    public double getHoogte()
    {
        return hoogte;
    }

    public void setHoogte(double hoogte)
    {
        this.stelHoogteIn(hoogte);
    }
    
    
    private void stelHoogteIn(double hoogte)
    {
        if (hoogte < 3) {
            throw new IllegalArgumentException("De hoogte moet minstens 3 zijn.");
        }
        
        this.hoogte = hoogte;
    }

    @Override
    public boolean isDraagbaar()
    {
        return false;
    }

    @Override
    public String toString()
    {
        return String.format("%s met hoogte %.1f is niet draagbaar.", this.naam, this.hoogte);
    }
    
    

}
