/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package domein;

import junit.framework.Assert;
import org.junit.Before;
import org.junit.Test;

/**
 *
 * @author docent
 */
public class DraagbaarRepositoryTest {
    
   private DraagbaarRepository verzameling;

    @Before
    public void before()
    {
        verzameling = new DraagbaarRepository();
    }

    @Test
    public void controleerlegeVerzameling()
    {
        Assert.assertEquals("collectie is leeg\n", verzameling.toonOverzicht());
    }

    @Test
    public void controleerEenWapenInVerzameling()
    {
        verzameling.voegDraagbaarItemToe(new Wapen("Colt", 1.5, 3, 6, false));
        Assert.assertEquals("Wapen Colt met gewicht 1.500 kg uit niveau 3 en met kracht 6 nog niet gebruikt.\n\n",
                verzameling.toonOverzicht());
    }

    @Test
    public void controleerEenSleutelInVerzameling()
    {
        verzameling.voegDraagbaarItemToe(new Sleutel("voordeur", 0.5, 3, 1));
        Assert.assertEquals("Sleutel voordeur met gewicht 0.500 kg uit niveau 3 past op deur 1.\nEr zijn 1 sleutel(s) in omloop.\n\n",
                verzameling.toonOverzicht());
    }

    @Test
    public void controleerEenGebouwInVerzameling()
    {
        verzameling.voegDraagbaarItemToe(new Gebouw("residentie Frankenstein", 4.5));
        Assert.assertEquals("residentie Frankenstein met hoogte 4.5 is niet draagbaar.\n\n", verzameling.toonOverzicht());
    }
    
}
