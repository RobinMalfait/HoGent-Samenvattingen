package domein;

import junit.framework.Assert;

import org.junit.Before;
import org.junit.Test;

public class GebouwTest
{

    private Gebouw gebouw1, gebouw2;

    @Before 
    public void before()
    {
        gebouw1 = new Gebouw("Residentie Frankenstein", 4.5);
        gebouw2 = new Gebouw("Delhaize", 8);
    }

    @Test(expected = IllegalArgumentException.class)
    public void geefFoutmeldingFouteHoogte()
    {
        gebouw2.setHoogte(2);
    }

    @Test
    public void gebouw1GetHoogte()
    {
        Assert.assertEquals(4.5, gebouw1.getHoogte());
    }


    @Test
    public void gebouwIsNietDraagbaar()
    {
        Assert.assertEquals(false, gebouw1.isDraagbaar());
    }
    
    @Test
    public void geefOutputVanGebouw()
    {
        Assert.assertEquals("Residentie Frankenstein met hoogte 4.5 is niet draagbaar.", gebouw1.toString());
    }

}
