package ui;

import domein.DomeinController;

/**
 *
 * @author robin
 */
public class Hoofdstuk10_Oef3 
{
    public void start()
    {
        DomeinController domeinController = new DomeinController();
        
        System.out.printf("%s%n%n", domeinController.toonTellers());
        System.out.println("Overzicht gemaakte kosten:");
        System.out.printf("%70s%15s%n", "Kostenpost", "Bedrag");
        System.out.println(domeinController.geefKostenLijst());  
    }
}
