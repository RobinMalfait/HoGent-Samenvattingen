package main;

import ui.Hoofdstuk10_Oef3;

/**
 *
 * @author robin
 */
public class StartUp 
{
    public static void main(String[] args)
    {
        try
        {
            (new Hoofdstuk10_Oef3()).start();
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
}
