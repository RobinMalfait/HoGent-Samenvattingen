package domein;

/**
 *
 * @author robin
 */
public interface Kosten
{
    public double berekenPrijs();
}
