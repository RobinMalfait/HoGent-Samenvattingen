package domein;

/**
 *
 * @author robin
 */
public class DomeinController 
{
    
    private final KostenRepository kr;

    public DomeinController()
    {
        this.kr = new KostenRepository();
    }
    
    public String toonTellers()
    {
        return this.kr.toonTellers();
    }
    
    public String geefKostenLijst()
    {
        return this.kr.geefKostenLijst();
    }
}
