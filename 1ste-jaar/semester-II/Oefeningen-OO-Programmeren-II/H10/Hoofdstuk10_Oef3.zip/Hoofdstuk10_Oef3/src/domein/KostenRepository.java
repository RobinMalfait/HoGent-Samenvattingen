package domein;

import java.util.List;
import persistentie.KostenMapper;

/**
 *
 * @author robin
 */
public class KostenRepository 
{
    private final KostenMapper km;
    
    private final List<Kosten> lijstje;

    public KostenRepository()
    {
        this.km = new KostenMapper();
        
        this.lijstje = this.km.geefKostenLijst();
    }
    
    public String toonTellers()
    {
        int aantalTickets = 0;
        int aantalVerplaatsingenPerAuto = 0;
        int aantalVerplaatsingenPerBusTram = 0;
        
        for (Kosten kost : this.lijstje) {
            if (kost instanceof Ticket) {
                aantalTickets++;
            } else if (kost instanceof VerplaatsingPerAuto) {
                aantalVerplaatsingenPerAuto++;
            } else if (kost instanceof VerplaatsingPerBusTram) {
                aantalVerplaatsingenPerBusTram++;
            }
        }        
        
        return String.format("Volgende documenten werden ingediend: %n%d ticket(s), %d verplaatsing(en) per auto en %d verplaatsing(en) per bus/tram",
            aantalTickets, 
            aantalVerplaatsingenPerAuto, 
            aantalVerplaatsingenPerBusTram
        );
    }
    
    public String geefKostenLijst()
    {
        String output = "";
        String omschrijving;
        double prijs;
        double totaleKosten = 0;
        
        for (Kosten kost : this.lijstje)
        {
            if (kost instanceof Ticket) {
                omschrijving = ((Ticket)kost).getOmschrijving();
                prijs = ((Ticket)kost).getPrijs();
            } else {
                omschrijving = ((Verplaatsing)kost).toString();
                prijs = ((Verplaatsing)kost).berekenPrijs() * 0.79;
            }
            
            totaleKosten += prijs;
            
            output += String.format("%70s%15.2f%n", omschrijving, prijs);
        }
        
        output+= String.format("%n%nTotaal gedeclareerde kosten = %7.2f", totaleKosten);
        
        return output;
    }      
}
