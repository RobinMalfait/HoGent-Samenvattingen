package domein;

/**
 *
 * @author robin
 */
public class Ticket implements Kosten
{
    private String omschrijving;
    
    private double prijs;

    public Ticket(String omschrijving, double prijs)
    {
        this.omschrijving = omschrijving;
        this.prijs = prijs;
    }

    public String getOmschrijving()
    {
        return omschrijving;
    }

    public void setOmschrijving(String omschrijving)
    {
        this.omschrijving = omschrijving;
    }

    public double getPrijs()
    {
        return prijs;
    }

    public void setPrijs(double prijs)
    {
        this.stelPrijsIn(prijs);
    }
    
    
    
    private void stelPrijsIn(double prijs)
    {
        if (prijs <= 0) {
            throw new IllegalArgumentException("De prijs moet een positief getal zijn");
        }
        
        this.prijs = prijs;
    }

    @Override
    public String toString()
    {
        return String.format("%20s%10.2f", "parkeerTicket", this.prijs);
    }
    
    @Override
    public double berekenPrijs()
    {
        return this.prijs;
    }

}
