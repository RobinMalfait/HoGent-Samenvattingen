package domein;

/**
 *
 * @author robin
 */
public abstract class Verplaatsing implements Kosten
{
    private String van;
    private String naar;
    private double aantalKm;

    public Verplaatsing(String van, String naar, double aantalKm)
    {
        this.van = van;
        this.naar = naar;
        this.aantalKm = aantalKm;
    }

    public String getVan()
    {
        return van;
    }

    public String getNaar()
    {
        return naar;
    }

    public double getAantalKm()
    {
        return aantalKm;
    }

    public void setVan(String van)
    {
        stelVanIn(van);
    }

    public void setNaar(String naar)
    {
        stelNaarIn(naar);
    }

    public void setAantalKm(double aantalKm)
    {
        stelAantalKmIn(aantalKm);
    }
    
    private void stelVanIn(String van)
    {
        if (van == null || van.isEmpty())
        {
            throw new IllegalArgumentException("Van locatie mag niet leeg zijn.");
        }
        
        this.van = van;
    }
    
    private void stelNaarIn(String naar)
    {
        if (naar == null || naar.isEmpty())
        {
            throw new IllegalArgumentException("Naar locatie mag niet leeg zijn.");
        }
        
        this.naar = naar;
    }
    
    private void stelAantalKmIn(double aantalKm)
    {
        if (aantalKm < 0)
        {
            throw new IllegalArgumentException("Het aantal km moet positief zijn.");
        }
        
        this.aantalKm = aantalKm;
    }

    @Override
    public String toString()
    {
        return String.format("verplaatsing van %s naar %s",
            this.van,
            this.naar
        );
    }        
}
