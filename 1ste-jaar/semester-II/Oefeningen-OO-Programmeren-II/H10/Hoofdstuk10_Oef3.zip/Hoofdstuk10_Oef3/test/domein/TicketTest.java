/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package domein;

import junit.framework.Assert;
import org.junit.Before;
import org.junit.Test;

/**
 *
 * @author sv964
 */
public class TicketTest
{
    
       private Ticket t;

    @Before
    public void before()
    {
        t = new Ticket("parkeerTicket", 5.5);
    }

     @Test
    public void controleerContructor(){
       
        Assert.assertEquals(5.5, t.getPrijs());
    }
    
    @Test
    public void controleerSetterPrijs(){
        t.setPrijs(8.2);
        Assert.assertEquals(8.2, t.getPrijs());
    }
    
    @Test(expected = IllegalArgumentException.class)
    public void controleerSetterFoutePrijs(){
        t.setPrijs(-8.2);
    }
    
           
    @Test
    public void controleerBerekenPrijs(){
         Assert.assertEquals(5.5, t.berekenPrijs());
    }    
    
    
    @Test
    public void omzettenNaarString()
    {
            Assert.assertEquals("       parkeerTicket      5.50", t.toString());
    }
        
}
