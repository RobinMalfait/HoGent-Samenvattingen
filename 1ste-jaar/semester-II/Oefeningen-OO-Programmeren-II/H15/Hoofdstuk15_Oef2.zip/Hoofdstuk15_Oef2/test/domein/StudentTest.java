package domein;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

/**
 * @author lvu621
 */
public class StudentTest
{
    private Student s1, s2;

    @Before
    public void before()
    {
        s1 = new Student("Peeters", "Piet", 22.3, 41.5);
    }
    
    @Test(expected = IllegalArgumentException.class)
    public void geefFoutBijConstructie()
    {
        s2 = new Student("Janssens", "Jan", -2.5, 17.75);
    }    
    
    @Test
    public void geefNaamNaConstructie()
    {
        Assert.assertEquals("Peeters", s1.getNaam());
    }
    
    @Test
    public void geefVoornaamNaConstructie()
    {
        Assert.assertEquals("Piet", s1.getVoornaam());
    }
    
    @Test
    public void geefPuntenOp20Constructie()
    {
        Assert.assertEquals(13, s1.getPuntenOp20());
    }   

    @Test(expected = IllegalArgumentException.class)
    public void geefFoutBijTeLaagAantalPuntenPE()
    {
        s1.setPuntenOp20(-8, 42);
    }
    
    @Test(expected = IllegalArgumentException.class)
    public void geefFoutBijTeLaagAantalPuntenExamen()
    {
        s1.setPuntenOp20(12, -41);
    }
    
    @Test(expected = IllegalArgumentException.class)
    public void geefFoutBijTeHoogAantalPuntenPE()
    {
        s1.setPuntenOp20(36, 36);
    }
    
    @Test(expected = IllegalArgumentException.class)
    public void geefFoutBijTeHoogAantalPuntenExamen()
    {
        s1.setPuntenOp20(27, 94);
    }   
    
    @Test
    public void geefTekstueleWeergave()
    {
        Assert.assertEquals
            (String.format("%25s%15s%5d", "Peeters", "Piet", 13), s1.toString());
    }
}
