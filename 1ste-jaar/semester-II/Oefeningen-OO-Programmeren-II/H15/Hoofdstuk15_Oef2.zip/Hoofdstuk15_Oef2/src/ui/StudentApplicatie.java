package ui;

import domein.DomeinController;

/**
 *
 * @author robin
 */
public class StudentApplicatie 
{

    public StudentApplicatie(DomeinController dc)
    {
        dc.haalStudentenGegevensOp();
        dc.schrijfVerwerktegegevens();
        
        System.out.println(dc.toonAlleInfo());
    }
    
}
