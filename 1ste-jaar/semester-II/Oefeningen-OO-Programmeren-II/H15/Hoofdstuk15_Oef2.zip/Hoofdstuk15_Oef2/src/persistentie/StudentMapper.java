package persistentie;

import domein.Student;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author robin
 */
public class StudentMapper 
{
    private final String invoerbestand = "studenten.txt";
    private final String geserialiseerd = "scores.ser";
    
    public List<Student> leesStudenten()
    {
        List<Student> studenten = new ArrayList<>();
        Scanner input = null;
        
        try
        {
            input = new Scanner(new File(invoerbestand));
            while (input.hasNext()) {
                studenten.add(new Student(input.next(), input.next(), input.nextDouble(), input.nextDouble()));
            }
        } 
        catch (IOException ex) { 
        }
        
        return studenten;
    }
    
    public void schrijfScores(List<Student> lijst)
    {
        try (ObjectOutputStream output = new ObjectOutputStream(new FileOutputStream(new File(geserialiseerd))))
        {
            output.writeObject(lijst);
        } catch (IOException ex)
        {
            System.err.println("Er ging wat fout met schrijven!");
        }
    }
}
