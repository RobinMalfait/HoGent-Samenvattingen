package domein;

/**
 *
 * @author robin
 */
public class DomeinController 
{
    private StudentRepository sr;
    
    public DomeinController()
    {
        this.sr = new StudentRepository();
    }
    
    public void haalStudentenGegevensOp()
    {
        this.sr.leesStudentenGegevens();
    }
    
    public void schrijfVerwerktegegevens()
    {
        this.sr.schrijfVerwerkteGegevens();
    }
    
    public String toonAlleInfo()
    {
        return this.sr.toString();
    }
    
}
