package domein;

import java.io.Serializable;

/**
 *
 * @author robin
 */
public class Student implements Serializable
{
    private final String naam, voornaam;
    private static final int MAXPE = 30;
    private static final int MAXEXAMEN = 70;
    private int puntenOp20;

    public Student(String naam, String voornaam, double puntenPE, double puntenExamen)
    {
        if (naam == null || naam.isEmpty()) 
        {
            throw new IllegalArgumentException("Naam moet ingevuld zijn!");
        }
        this.naam = naam;
        
        if (voornaam == null || voornaam.isEmpty())
        {
            throw new IllegalArgumentException("Voornaam moet ingevuld zijn!");
        }
        this.voornaam = voornaam;
        
        stelPuntenOp20In(puntenPE, puntenExamen);
        
    }

    public String getNaam()
    {
        return naam;
    }

    public String getVoornaam()
    {
        return voornaam;
    }

    public int getPuntenOp20()
    {
        return puntenOp20;
    }

    public void setPuntenOp20(double puntenPE, double puntenExamen)
    {
        this.stelPuntenOp20In(puntenPE, puntenExamen);
    }

    private void stelPuntenOp20In(double puntenPE, double puntenExamen)
    {
        if (puntenPE > MAXPE || puntenPE < 0) 
        {
            throw new IllegalArgumentException("Punten PE moet binnen de grenzen [0, "+MAXPE+"] liggen!");
        }
        
        if (puntenExamen > MAXEXAMEN || puntenExamen < 0)
        {
            throw new IllegalArgumentException("Punten Examen moet binnen de grenzen [0, "+MAXEXAMEN+"] liggen!");
        }
        
        this.puntenOp20 = (int) Math.round((puntenPE + puntenExamen) / 5);
    }

    @Override
    public String toString()
    {
        return String.format("%25s%15s%5d", this.naam, this.voornaam, this.puntenOp20);
    }
    
    
}