package domein;

import java.util.List;
import persistentie.StudentMapper;

/**
 *
 * @author robin
 */
public class StudentRepository 
{
    private StudentMapper sm;
    private List<Student> studenten;

    public StudentRepository()
    {
        this.sm = new StudentMapper();
    }
    
    public void leesStudentenGegevens()
    {
        this.studenten = this.sm.leesStudenten();
    }
    
    public void schrijfVerwerkteGegevens()
    {
        this.sm.schrijfScores(this.studenten);
    }

    @Override
    public String toString()
    {
        StringBuilder output = new StringBuilder();
        
        int aantal = 0;
        int geslaagd = 0;
        int nietGeslaagd = 0;
        double totalScore = 0;
        
        for(Student student : this.studenten) {
            output.append(student.toString() + "\n");
            
            if (student.getPuntenOp20() < 10) {
                nietGeslaagd++;
            } else {
                geslaagd++;
            }
            
            totalScore += student.getPuntenOp20();
            
            aantal++;
        }
        
        output.append(String.format("%n%d student verwerkt: %d geslaagd, %d niet geslaagd%ngemiddelde score: %.1f", 
                aantal, 
                geslaagd, 
                nietGeslaagd, 
                totalScore/aantal)
        );
        
        return output.toString();
    }
    
}
