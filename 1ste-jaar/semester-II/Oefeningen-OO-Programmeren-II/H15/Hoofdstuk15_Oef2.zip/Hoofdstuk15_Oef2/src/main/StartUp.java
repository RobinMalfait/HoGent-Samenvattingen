package main;

import domein.DomeinController;
import ui.StudentApplicatie;

/**
 *
 * @author robin
 */
public class StartUp 
{
    public static void main(String[] args)
    {
        new StudentApplicatie(new DomeinController());
    }
}
