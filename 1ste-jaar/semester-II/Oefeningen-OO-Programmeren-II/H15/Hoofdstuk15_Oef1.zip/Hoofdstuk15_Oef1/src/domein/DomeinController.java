package domein;

import java.util.List;
import persistentie.VliegmaatschappijMapper;

/**
 *
 * @author robin
 */
public class DomeinController 
{

    private final List<Vliegmaatschappij> maatschappijen;
    private final VliegmaatschappijMapper vm;
    
    public DomeinController()
    {
        vm = new VliegmaatschappijMapper();
        maatschappijen = vm.leesTekstBestand("airlines.txt");
    }
    
    public String geefAirlines() 
    {
        StringBuilder uitvoer = new StringBuilder("");
        
        for (Vliegmaatschappij vm : this.maatschappijen)
        {
            uitvoer.append(vm.toString());
        }
        
        return uitvoer.toString();
    }
}
