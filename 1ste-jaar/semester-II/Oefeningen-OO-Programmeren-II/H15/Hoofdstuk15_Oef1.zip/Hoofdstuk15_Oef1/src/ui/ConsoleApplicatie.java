package ui;

import domein.DomeinController;

/**
 *
 * @author robin
 */
public class ConsoleApplicatie 
{

    public ConsoleApplicatie(DomeinController dc)
    {
        System.out.println(dc.geefAirlines());
    }
    
}
