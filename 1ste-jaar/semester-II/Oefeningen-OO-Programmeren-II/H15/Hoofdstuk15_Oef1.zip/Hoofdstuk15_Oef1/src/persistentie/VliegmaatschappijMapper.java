package persistentie;

import domein.Vliegmaatschappij;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 *
 * @author robin
 */
public class VliegmaatschappijMapper 
{

    public List<Vliegmaatschappij> leesTekstBestand(String bestand)
    {
        List<Vliegmaatschappij> airlines = new ArrayList<>();
        Scanner input = null;
        
        try
        {
            input = new Scanner(new FileInputStream(bestand));
            
            while (input.hasNext())
            {
                airlines.add(new Vliegmaatschappij(input.nextLine().split(",")));
            }
        } 
        catch (FileNotFoundException ex) {
            System.err.printf("Bestand %s niet gevonden!", bestand);
        } finally {
            if (input != null) {
                input.close();
            }
        }
        
        return airlines;
    }
    
}
