package domein;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class VliegmaatschappijTest 
{
    private Vliegmaatschappij v1, v2;
    private String[] data1, data2;
    
    @Before
    public void before()
    {
        data1 = new String[] {"Brussels Airlines", "Canada Air", "Lufthansa", "Swiss Air"};
        data2 = new String[] {};
        v1 = new Vliegmaatschappij(data1);
    }
    
    @Test(expected = IllegalArgumentException.class)
    public void geefFoutBijVliegmaatschappijZonderData()
    {
        v2 = new Vliegmaatschappij(data2);
    }
    
    @Test
    public void geefNaam()
    {    
        Assert.assertEquals("Brussels Airlines", v1.getNaam());
    }
    
    @Test
    public void geefPartners()
    {
        String[] gegevens = new String[] {"Canada Air", "Lufthansa", "Swiss Air"};
        List<String> partners = Arrays.asList(gegevens);
        Assert.assertEquals(partners, v1.getPartners());
    }

    @Test
    public void controleerBestaandePartner()
    {
        Assert.assertTrue(v1.isPartner("Lufthansa"));
    }

    @Test
    public void controleerOnbestaandePartner()
    {
        Assert.assertFalse(v1.isPartner("KLM"));
    }
    
    @Test
    public void geefTekstweergave()
    {
        Assert.assertEquals(
                String.format("Brussels Airlines met partners [Canada Air, Lufthansa, Swiss Air]%n"), 
                v1.toString());
    }
}