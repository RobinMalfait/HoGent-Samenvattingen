package domein;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class NamenTest
{
    private Namen n1, n2;

    @Before
    public void before()
    {
        n1 = new Namen("Roobrouck");
        n2 = new Namen("Janssens");
    }
    
    @Test
    public void geefTeZoekenNaamNaConstructie1()
    {
        Assert.assertEquals("Roobrouck", n1.getTeZoeken());
    }    
    
    @Test (expected = IllegalArgumentException.class)
    public void wijzigTeZoekenNaam1()
    {
        n2.setTeZoeken(null);
    }
    
    @Test
    public void wijzigTeZoekenNaam2()
    {
        n2.setTeZoeken("Vuyge");
        Assert.assertEquals("Vuyge", n2.getTeZoeken());
    }
    
    @Test
    public void isNaamAanwezig1()
    {
        Assert.assertTrue(n1.isAanwezig());
    }

    @Test
    public void isNaamAanwezig2()
    {
        Assert.assertFalse(n2.isAanwezig());
    }

    @Test
    public void geefAantalVorige()
    {
        Assert.assertEquals(4, n1.geefAantalVorigeNamen());
    }
}
