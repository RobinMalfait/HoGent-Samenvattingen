package GUI;

import javafx.scene.layout.VBox;

/**
 * FXML Controller class
 *
 * @author robin
 */
public class OpzoekSchermController extends VBox
{
    
}
