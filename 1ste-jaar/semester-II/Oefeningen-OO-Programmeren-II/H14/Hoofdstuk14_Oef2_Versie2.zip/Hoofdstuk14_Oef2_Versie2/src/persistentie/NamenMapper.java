package persistentie;

/**
 *
 * @author robin
 */
public class NamenMapper 
{
    public String[] geefNamenlijst()
    {
        String[] lijst = {"Roobrouck", "Roobroeck", "Brandt", "Bernard", "Barbier", "Vandermeersch", "Van Schoor", "Vanenens"};
        
        return lijst;
    }
}
