package domein;

import java.util.Arrays;
import persistentie.NamenMapper;

/**
 *
 * @author robin
 */
public class Namen 
{
    private final String[] lijstNamen;
    private String teZoeken;
    private final NamenMapper nm;
        
    public Namen(String teZoeken)
    {
        nm = new NamenMapper();
        lijstNamen = nm.geefNamenlijst();
        Arrays.sort(lijstNamen);
        
        stelTeZoekenIn(teZoeken);
    }
    
    private void stelTeZoekenIn(String teZoeken)
    {
        if (teZoeken == null || teZoeken.isEmpty())
        {
            throw new IllegalArgumentException("Vul de te zoeken naam in!");
        }
        
        this.teZoeken = teZoeken;
    }
    
    public String getTeZoeken()
    {
        return teZoeken;
    }

    public void setTeZoeken(String teZoeken)
    {
        stelTeZoekenIn(teZoeken);
    }

    public boolean isAanwezig()
    {      
        return this.geefAantalVorigeNamen() >= 0;
    }

    public int geefAantalVorigeNamen()
    {
        return Arrays.binarySearch(lijstNamen, teZoeken);
    }
}
