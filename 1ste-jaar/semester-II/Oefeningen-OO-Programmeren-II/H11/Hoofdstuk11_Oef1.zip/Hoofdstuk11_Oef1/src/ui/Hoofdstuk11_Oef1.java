package ui;

import domein.DomeinController;
import java.util.InputMismatchException;
import java.util.Scanner;

/**
 *
 * @author robin
 */
public class Hoofdstuk11_Oef1 
{
    
    private final DomeinController dc;
    private final Scanner input;

    public Hoofdstuk11_Oef1()
    {
        this.dc = new DomeinController();
        this.input = new Scanner(System.in);
    }
    
    public void start()
    {
        int keuze = 0;
        do {
            keuze = this.geefKeuzeUitMenu();
            
            switch(keuze) {
                case 1: this.voegWapenToe(); break;
                case 2: this.voegSleutelToe(); break;
                case 3: this.voegGebouwToe(); break;
                case 4: 
                    System.out.println(this.dc.toonOverzicht());
                    break;
            }
            
        } while(keuze != 5);
    }
    
    private int geefKeuzeUitMenu()
    {
        int keuze = 0;
        
        do {
            try {
                System.out.println("Kies uit:");
                System.out.println("1. Voeg wapen toe");
                System.out.println("2. Voeg sleutel toe");
                System.out.println("3. Voeg gebouw toe");
                System.out.println("4. Toon huidig overzicht");
                System.out.println("5. Beëindig deze applicatie");
                System.out.printf("Je keuze is: ");

                keuze = this.input.nextInt();
                
            } catch (InputMismatchException e) {
                System.out.printf("Voer een geheel getal in.%n");
                this.input.nextLine(); // Clear buffer
            }
        } while (keuze <= 0 || keuze > 5);
        
        return keuze;
    }
    
    private void voegWapenToe()
    {
        /**
         * Naam
         */
        String naam = "";
        do {
            try {
                System.out.printf("Geef een naam (zonder spaties): ");    
                naam = this.input.next();             
            } catch(InputMismatchException e) {
                System.out.printf("Gelieve een naam zonder spaties te geven.%n");
            }
        } while(naam.equals(""));
        
        /**
         * Gewicht
         */
        double gewicht = 0;
        do {
            try {
                System.out.printf("Geef het gewicht: ");    
                gewicht = this.input.nextDouble();
            } catch(InputMismatchException e) {
                System.out.printf("Gelieve een getal tussen [0, 1000] in te voeren (Let op een \",\" kan een \".\" zijn.%n"); 
                input.nextLine(); // Clear Buffer
            }
            
        } while(gewicht < 0 || gewicht > 1000);
        
        /**
         * Niveau
         */
        int niveau;
        do {
            System.out.printf("Geef het niveau: ");    
            niveau = this.input.nextInt();
        } while(niveau < 1 || niveau > 10);
        
        /**
         * Kracht
         */
        int kracht;
        do {
            System.out.printf("Geef de kracht: ");    
            kracht = this.input.nextInt();
        } while(kracht < 0);
        

        /**
         * Gebruikt
         */
        boolean gebruikt = false;
        boolean allesOk = true;
        do {
            try {
                allesOk = true;
                System.out.printf("Werd het wapen reeds gebruikt (true/false): ");    
                gebruikt = this.input.nextBoolean();
            } catch(InputMismatchException e) {                
                allesOk = false;
                System.out.printf("Enkel true of false is toegestaan!%n");
                input.nextLine(); // Clear Buffer
            }
            
        } while( ! allesOk);
        
        /**
         * Voeg wapen effectief toe!
         */
        this.dc.voegWapenToe(naam, gewicht, niveau, kracht, gebruikt);
        
    }
    
    private void voegSleutelToe()
    {
        /**
         * Naam
         */
        String naam = "";
        do {
            try {
                System.out.printf("Geef een naam (zonder spaties): ");    
                naam = this.input.next();             
            } catch(InputMismatchException e) {
                System.out.printf("Gelieve een naam zonder spaties te geven.%n");
            }
        } while(naam.equals(""));
        
        /**
         * Gewicht
         */
        double gewicht = 0;
        do {
            try {
                System.out.printf("Geef het gewicht: ");    
                gewicht = this.input.nextDouble();
            } catch(InputMismatchException e) {
                System.out.printf("Gelieve een getal tussen [0, 1000] in te voeren (Let op een \",\" kan een \".\" zijn.%n"); 
                input.nextLine(); // Clear Buffer
            }
            
        } while(gewicht < 0 || gewicht > 1000);
        
        /**
         * Niveau
         */
        int niveau;
        do {
            System.out.printf("Geef het niveau: ");    
            niveau = this.input.nextInt();
        } while(niveau < 1 || niveau > 10);
        
        /**
         * Deur nummer
         */
        int deur = 0;
        boolean allesOk = true;
        do {
            try {
                allesOk = true;
                System.out.printf("Geef het nummer van de deur: ");    
                deur = this.input.nextInt();
            } catch(InputMismatchException e) {
                allesOk = false;
                System.out.printf("Gelive een geheel getal in te voeren%n");
                input.nextLine(); // Clear buffer
            }
        } while( ! allesOk);
        
        /**
         * Voeg sleutel effectief toe!
         */
        this.dc.voegSleutelToe(naam, gewicht, niveau, deur);
    }
    
    private void voegGebouwToe()
    {
        /**
         * Naam
         */
        String naam = "";
        do {
            try {
                System.out.printf("Geef een naam (zonder spaties): ");    
                naam = this.input.next();             
            } catch(InputMismatchException e) {
                System.out.printf("Gelieve een naam zonder spaties te geven.%n");
            }
        } while(naam.equals(""));
        
        
        /**
         * Hoogte
         */
        int hoogte = 0;
        do {
            try {
                System.out.printf("Geef de hoogte: ");    
                hoogte = this.input.nextInt();
            } catch(InputMismatchException e) {
                System.out.printf("De hoogte moet minstens 3m zijn!%n");
                input.nextLine(); // Clear buffer
            }
        } while(hoogte < 3);
        
        /**
         * Voeg gebouw effectief toe!
         */
        this.dc.voegGebouwToe(naam, hoogte);
    }
}
