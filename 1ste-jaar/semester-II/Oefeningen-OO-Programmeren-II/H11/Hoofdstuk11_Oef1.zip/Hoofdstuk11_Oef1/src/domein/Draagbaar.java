package domein;

/**
 *
 * @author robin
 */
public interface Draagbaar 
{
    public boolean isDraagbaar();
}
