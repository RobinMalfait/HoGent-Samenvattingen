package domein;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author robin
 */
public class DraagbaarRepository 
{
    
    private final List<Draagbaar> collectie;

    public DraagbaarRepository()
    {
        this.collectie = new ArrayList<>();
    }
    
    public void voegDraagbaarItemToe(Draagbaar draagbaarItem)
    {
        this.collectie.add(draagbaarItem);
    }
    
    public String toonOverzicht()
    {
        if (this.collectie.isEmpty()) {
            return "collectie is leeg\n";
        }

        String output = "";

        for (Draagbaar item : this.collectie)
        {
            output += String.format("%s%n%n", item);
        }

        return output;
    }
}
