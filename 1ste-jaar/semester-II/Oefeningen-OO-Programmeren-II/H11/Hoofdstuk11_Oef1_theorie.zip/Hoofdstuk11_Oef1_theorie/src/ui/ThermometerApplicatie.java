package ui;

import domein.Thermometer;
import java.util.InputMismatchException;
import java.util.Scanner;

/**
 *
 * @author robin
 */
public class ThermometerApplicatie
{

    public ThermometerApplicatie(Thermometer thermometer)
    {
        Scanner input = new Scanner(System.in);
        int temperatuur;
        boolean invoerFout = true;

        do
        {
            try
            {
                System.out.printf("Geef een temperatuur (eenheid Fahrenheit) in het interval [14, 104]: ");
                temperatuur = input.nextInt();
                
                if (temperatuur > 104 || temperatuur < 14) {
                    throw new IllegalArgumentException("De waarde moest tussen 14 en 104 liggen!");
                }
                
                thermometer.setAantalGraden(temperatuur);
                
                System.out.printf("De temperatuur is %d°C%n", thermometer.converteerNaarCelcius());
                
                invoerFout = false;                
            } catch (InputMismatchException e) {
                System.out.printf("Foutieve invoer! Moet numeriek zijn!%n");
                input.nextLine(); // Clear buffer
            } catch(IllegalArgumentException e) {
                System.out.printf("%s%n", e.getMessage());
                input.nextLine(); // Clear buffer
            } catch(Exception e) {
                System.out.printf("Probeer opnieuw!%n");
            }
            
        } while (invoerFout);

    }

}
