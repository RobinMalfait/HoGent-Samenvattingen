package domein;

/**
 *
 * @author robin
 */
public class Thermometer 
{
    private int aantalGraden;

    public Thermometer()
    {
        this(32);
    }

    public Thermometer(int aantalGraden)
    {
        this.setAantalGraden(aantalGraden);
    }

    public int getAantalGraden()
    {
        return this.aantalGraden;
    }

    public void setAantalGraden(int aantalGraden)
    {
        this.aantalGraden = aantalGraden;
    }
    
    public int converteerNaarCelcius()
    {
        return (int) ((this.aantalGraden - 32) / 1.8);
    }
    
}
