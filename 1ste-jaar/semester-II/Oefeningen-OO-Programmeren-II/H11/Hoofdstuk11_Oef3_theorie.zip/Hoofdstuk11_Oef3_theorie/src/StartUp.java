import domein.Thermometer;
import ui.ThermometerApplicatie;

/**
 *
 * @author robin
 */
public class StartUp 
{
    public static void main(String[] args)
    {
        ThermometerApplicatie thermometerApplicatie = new ThermometerApplicatie(new Thermometer());
    }
}
