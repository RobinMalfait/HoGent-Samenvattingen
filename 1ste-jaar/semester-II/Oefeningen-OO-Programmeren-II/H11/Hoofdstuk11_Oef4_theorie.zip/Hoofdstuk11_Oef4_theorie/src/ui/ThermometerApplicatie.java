package ui;

import domein.Thermometer;
import exceptions.OutOfRangeException;
import java.util.InputMismatchException;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author robin
 */
public class ThermometerApplicatie
{

    public ThermometerApplicatie(Thermometer thermometer)
    {
        Scanner input = new Scanner(System.in);
        boolean invoerFout = true;

        do
        {
            try
            {
                System.out.printf("Geef een temperatuur (eenheid Fahrenheit) in het interval [14, 104]: ");

                thermometer.stelAantalGradenIn(input.next());
                
                System.out.printf("De temperatuur is %d°C%n", thermometer.converteerNaarCelcius());
                
                invoerFout = false;                
            } catch (InputMismatchException e) {
                
                System.out.printf("Foutieve invoer! Moet numeriek zijn!%n");
                input.nextLine(); // Clear buffer
                
            } catch(IllegalArgumentException | OutOfRangeException e) {
                
                System.out.printf("%s%n", e.getMessage());
                input.nextLine(); // Clear buffer
                
            }
            
        } while (invoerFout);

    }

}
