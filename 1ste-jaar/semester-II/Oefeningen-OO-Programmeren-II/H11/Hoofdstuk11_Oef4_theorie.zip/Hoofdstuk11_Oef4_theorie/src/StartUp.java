import domein.Thermometer;
import exceptions.OutOfRangeException;
import ui.ThermometerApplicatie;

/**
 *
 * @author robin
 */
public class StartUp 
{
    public static void main(String[] args) throws OutOfRangeException
    {
        ThermometerApplicatie thermometerApplicatie = new ThermometerApplicatie(new Thermometer());
    }
}
