package exceptions;

/**
 *
 * @author robin
 */
public class OutOfRangeException extends Exception
{

    public OutOfRangeException()
    {
        super("Getal buiten het interval [14, 104]");
    }

    public OutOfRangeException(String message)
    {
        super(message);
    }
    
}
