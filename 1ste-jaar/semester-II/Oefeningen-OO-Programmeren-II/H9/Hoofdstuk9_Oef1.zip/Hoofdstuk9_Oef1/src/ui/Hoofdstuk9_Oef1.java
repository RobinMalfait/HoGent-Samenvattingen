package ui;

import domein.Sleutel;
import domein.Voorwerp;
import domein.Wapen;

/**
 *
 * @author robin
 */
public class Hoofdstuk9_Oef1 
{
    public void start()
    {
        Voorwerp voorwerpen[] = new Voorwerp[4];
        
        // Wapens
        voorwerpen[0] = new Wapen("colt", 1.5, 3, 6, false);
        voorwerpen[1] = new Wapen("brown", 0.5, 1, 23, true);
        
        // Sleutels
        voorwerpen[2] = new Sleutel("voordeur", 0.5, 3, 1);
        voorwerpen[3] = new Sleutel("achterdeur", 0.5, 1, 2);
        
        for (Voorwerp voorwerp : voorwerpen)
        {
            System.out.println(voorwerp);
        }
    }
}
