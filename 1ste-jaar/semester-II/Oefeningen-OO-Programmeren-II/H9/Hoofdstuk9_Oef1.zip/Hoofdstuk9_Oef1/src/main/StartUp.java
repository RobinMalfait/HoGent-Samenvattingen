package main;

import ui.Hoofdstuk9_Oef1;

/**
 *
 * @author robin
 */
public class StartUp 
{
    public static void main(String[] args)
    {
        Hoofdstuk9_Oef1 oef1 = new Hoofdstuk9_Oef1();
        
        oef1.start();
    }
}
