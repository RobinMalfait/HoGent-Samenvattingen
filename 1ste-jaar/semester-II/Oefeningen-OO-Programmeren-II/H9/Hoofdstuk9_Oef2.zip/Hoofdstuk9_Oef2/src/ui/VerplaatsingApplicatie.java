package ui;

import domein.VerplaatsingPerAuto;
import domein.VerplaatsingPerBusTram;

/**
 *
 * @author robin
 */
public class VerplaatsingApplicatie 
{
    public void start()
    {
        double totaleKostPrijs = 0;
        double prijs;
        
        VerplaatsingPerAuto perAuto[] = new VerplaatsingPerAuto[2];
        VerplaatsingPerBusTram perBusTram[] = new VerplaatsingPerBusTram[2];
        
        perAuto[0] = new VerplaatsingPerAuto("HoGent campus Schoonmeersen Gent", "EFFIX Waregem", 29.4, 1.591, 0.0538);
        perAuto[1] = new VerplaatsingPerAuto("HoGent campus Aalst", "Brenso NV Affligem", 23.8, 1.314, 0.0477);
        
        perBusTram[0] = new VerplaatsingPerBusTram("HoGent campus Schoonmeersen Gent", "Technologiepark Zwijnaarde", 12, 70, true, false);
        perBusTram[1] = new VerplaatsingPerBusTram("Sint-Pietersstation Gent", "Vijfwindgatenstraat Gent", 12, 22, false, true);
        
        for (VerplaatsingPerAuto auto : perAuto)
        {
            prijs = auto.berekenPrijs();
            
            System.out.println(auto);
            totaleKostPrijs += prijs;
            System.out.printf("Kosten voor deze verplaatsing: € %.2f%n%n", prijs);
        }
        
        for (VerplaatsingPerBusTram busTram : perBusTram)
        {
            prijs = busTram.berekenPrijs();
            
            System.out.println(busTram);
            totaleKostPrijs += prijs;
            System.out.printf("Kosten voor deze verplaatsing: € %.2f%n%n", prijs);
        }
        
        System.out.printf("Totale kosten voor alle verplaatsigen samen: € %.2f%n", totaleKostPrijs);
    }
}
