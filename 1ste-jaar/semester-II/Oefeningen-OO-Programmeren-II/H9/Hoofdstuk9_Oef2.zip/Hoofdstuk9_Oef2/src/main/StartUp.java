package main;

import ui.VerplaatsingApplicatie;

/**
 *
 * @author robin
 */
public class StartUp 
{
    public static void main(String[] args)
    {
        (new VerplaatsingApplicatie()).start();
    }
}
