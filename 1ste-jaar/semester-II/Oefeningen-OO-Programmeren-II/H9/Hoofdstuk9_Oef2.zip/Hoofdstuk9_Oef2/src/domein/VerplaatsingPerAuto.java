package domein;

/**
 *
 * @author robin
 */
public class VerplaatsingPerAuto extends Verplaatsing
{
    private double benzineprijs;
    private double verbruik;

    public VerplaatsingPerAuto(String van, String naar, double aantalKm, double benzineprijs, double verbruik)
    {
        super(van, naar, aantalKm);
        this.benzineprijs = benzineprijs;
        this.verbruik = verbruik;
    }

    public double getBenzineprijs()
    {
        return benzineprijs;
    }

    public double getVerbruik()
    {
        return verbruik;
    }

    public void setBenzineprijs(double benzineprijs)
    {
        stelBenzineprijsIn(benzineprijs);
    }

    public void setVerbruik(double verbruik)
    {
        stelVerbruikIn(verbruik);
    }

    private void stelVerbruikIn(double verbruik1) throws IllegalArgumentException
    {
        if (verbruik1 < 0.02 || verbruik1 > 0.07)
        {
            throw new IllegalArgumentException("Het verbruik moet tussen [0.02; 0.07] liggen.");
        }
        this.verbruik = verbruik1;
    }
    
    private void stelBenzineprijsIn(double benzineprijs) throws IllegalArgumentException
    {
        if (benzineprijs < 0.5 || benzineprijs > 2.0)
        {
            throw new IllegalArgumentException("De benzineprijs moet tussen [0.50; 2.00] liggen.");
        }
        
        this.benzineprijs = benzineprijs;
    }
    
    public double berekenPrijs()
    {
        return this.verbruik * this.benzineprijs * super.getAantalKm() * 2;
    }

    @Override
    public String toString()
    {
        return super.toString() + " per auto";
    }
    
    
    
}
