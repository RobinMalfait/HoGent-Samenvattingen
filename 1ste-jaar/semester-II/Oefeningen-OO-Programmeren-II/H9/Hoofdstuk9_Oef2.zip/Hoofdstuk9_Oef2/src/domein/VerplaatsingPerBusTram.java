package domein;

/**
 *
 * @author robin
 */
public class VerplaatsingPerBusTram extends Verplaatsing
{
    private int lijnnr;
    private boolean bus;
    private boolean stadslijn;
    
    private static final double PRIJS_PER_HALTE = 0.32;

    public VerplaatsingPerBusTram(String van, String naar, double aantalKm, int lijnnr, boolean bus, boolean stadslijn)
    {
        super(van, naar, aantalKm);
        
        this.lijnnr = lijnnr;
        this.bus = bus;
        this.stadslijn = stadslijn;
    }

    public int getLijnnr()
    {
        return lijnnr;
    }

    public boolean isBus()
    {
        return bus;
    }

    public boolean isStadslijn()
    {
        return stadslijn;
    }

    public void setLijnnr(int lijnnr)
    {
        if (lijnnr <= 0)
        {
            throw new IllegalArgumentException("Lijn nr moet strikt positief zijn.");
        }
        
        this.stelLijnnrIn(lijnnr);
    }

    public void setBus(boolean bus)
    {
        this.stelBusIn(bus);
    }

    public void setStadslijn(boolean stadslijn)
    {
        this.stelStadslijnIn(stadslijn);
    }    
    
    private void stelLijnnrIn(int lijnnr)
    {
        this.lijnnr = lijnnr;
    }
    
    private void stelBusIn(boolean bus)
    {
        this.bus = bus;   
    }
    
    private void stelStadslijnIn(boolean stadslijn)
    {
        this.stadslijn = stadslijn;
    }
    
    public double berekenPrijs()
    {
        int aantalHaltes = (int) Math.ceil(super.getAantalKm());
        double prijs = 2 * aantalHaltes * PRIJS_PER_HALTE;
        
        if (this.stadslijn) {
            prijs *= 0.80; // 100% = totaal; 20% = 100-20 = 0.80
        }
        
        return prijs;
    }

    @Override
    public String toString()
    {
        return String.format("%s met stads%s %d", super.toString(), this.stadslijn ? "tram" : "bus", this.lijnnr);
    }
    
    
    

}
