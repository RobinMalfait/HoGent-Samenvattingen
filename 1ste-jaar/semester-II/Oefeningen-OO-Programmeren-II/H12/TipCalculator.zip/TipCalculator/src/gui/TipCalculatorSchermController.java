package gui;

import domein.TipCalculator;
import java.io.IOException;
import java.math.BigDecimal;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Slider;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;

/**
 * FXML Controller class
 *
 * @author robin
 */
public class TipCalculatorSchermController extends GridPane
{
    @FXML
    private Label lblTipPercentage;
    @FXML
    private TextField txtAmount;
    @FXML
    private TextField txtTip;
    @FXML
    private TextField txtTotal;
    @FXML
    private Slider sldTipPercentage;
    @FXML
    private Button btnCalculate;

    private TipCalculator dc;

    public TipCalculatorSchermController(TipCalculator dc)
    {
        this.dc = dc;
                
        FXMLLoader loader = new FXMLLoader(getClass().getResource("TipCalculatorScherm.fxml"));
        
        loader.setRoot(this);
        loader.setController(this);
        
        try {
            loader.load();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        
        this.sldTipPercentage.valueProperty().addListener(new ChangeListener<Number>() 
        {

            @Override
            public void changed(ObservableValue<? extends Number> observable, Number oldValue, Number newValue)
            {
                BigDecimal tipPercentage = BigDecimal.valueOf(newValue.intValue());
                TipCalculatorSchermController.this.lblTipPercentage.setText(String.format("%s%%", tipPercentage));
            }
        });
    }
    
    @FXML
    private void btnCalculateOnAction(ActionEvent event)
    {
        try {
            BigDecimal amount = new BigDecimal(this.txtAmount.getText());
            this.dc.setBedrag(amount);
            double tip = this.dc.berekenTip(Math.floor(this.sldTipPercentage.getValue()) / 100);
            this.txtTip.setText(String.format("%.2f", tip));
            this.txtTotal.setText(String.format("%.2f", amount.add(new BigDecimal(tip)).doubleValue()));
        } catch (NumberFormatException e) {
            this.txtAmount.setText("Enter amount");
            this.txtAmount.selectAll();
            this.txtAmount.requestFocus();
        } catch (IllegalArgumentException e) {
            this.txtAmount.setText(e.getMessage());
            this.txtAmount.selectAll();
            this.txtAmount.requestFocus();
        }
    }
    
    
    
}
