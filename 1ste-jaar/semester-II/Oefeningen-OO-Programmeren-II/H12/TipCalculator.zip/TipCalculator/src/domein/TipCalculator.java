package domein;

import java.math.BigDecimal;

/**
 *
 * @author robin
 */
public class TipCalculator 
{
    private BigDecimal bedrag;

    public TipCalculator()
    {
    }
    
    public TipCalculator(BigDecimal bedrag)
    {
        this.setBedrag(bedrag);
    }
    
    public BigDecimal getBedrag()
    {
        return this.bedrag;
    }
    
    public void setBedrag(BigDecimal bedrag)
    {
        if (bedrag.doubleValue() < 0) {
            throw new IllegalArgumentException("Geen negatief bedrag toegelaten!");
        }
        
        this.bedrag = bedrag;
    }
    
    public double berekenTip(double percentage)
    {
        return this.bedrag.doubleValue() * percentage;
    }
    
}
